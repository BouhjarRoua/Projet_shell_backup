#!/bin/bash
source archiver.sh
source restaurer.sh
source savoir.sh
source nettoyer.sh
main()
{

case $1 in
"-G") source menu.sh
;;
"-ar") archiver
;;
"-re")  restaurer
;;
"-sa")  savoir
;;
"-clean")  nettoyer
;;
"-help") cat help.txt
;;
*) echo "rien a ete ,entrez -help pour help"
;;
esac
}
main $1
